<?php

if ( isset($_GET['id'])) {
	#echo "Informasi ";
	$id = $_GET['id'];
	$waktu = $_GET['updated'];
	
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'anamedsos';

	$connection =  mysqli_connect($host, $username, $password, $dbname) or die('Database Connection Failed');
	mysqli_set_charset($connection,'utf-8');

	$query = "SELECT * FROM gender_submission_logs WHERE GroupName = '$id' AND updated='$waktu'";
	$result = mysqli_query($connection,$query) 
		   or die('Error, query failed');
	list($UploadKey, $GroupName, $filename, $mime, $size, $updated, $data, $TesterAccuracy, $TesterPrecision, $TesterRecall, $TesterF1Score ) = mysqli_fetch_array($result);

	$regex = '/\d+\,.*/';
	preg_match_all($regex, $data, $matches);
	foreach($matches[0] as $idx=>$piece) {
		echo $piece.'<br>';
	}

	mysqli_close($connection);
}

?>